import { Component } from '@angular/core';
import { StorageService } from '../services/storage.service';
import { ToastController } from '@ionic/angular';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  value:any;

  constructor(
    private storage: StorageService,
    private toast: ToastController,
  ) {
    this.storage.set('token', 'asdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdaadsf')
      .then(() => {
        this.storage.get('token').then(resp => {
          this.value = resp;
        });
      });

    setTimeout(() => {
      this.storage.remove('token');
      
      this.toast.create({
        message: "Registro eliminado!",
        showCloseButton: true,
      }).then(toast => toast.present());

      this.storage.get('token').then(resp => {
        this.value = resp;
      });

    }, 5000)
  }
}
